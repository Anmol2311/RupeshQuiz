export class Stud{
    email:string;
    password:string;
}