export class Question {
    exam_code: string;
    que:string;
    opt1:string;
    opt2:string;
    opt3:string;
    opt4:string;
    ans:string;
}