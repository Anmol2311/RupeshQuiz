export class Result{
    student_name:string;
    exam_name:string;
    total_que:number;
    correct_ans:number;
    wrong_ans:number;
    exam_date:Date;
    result:string;
}