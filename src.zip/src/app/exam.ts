export class Exam {
    exam_code: string;
    exam_name: string;    
}